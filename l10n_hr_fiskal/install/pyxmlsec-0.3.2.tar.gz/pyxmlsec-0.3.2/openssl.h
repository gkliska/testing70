#include <xmlsec/openssl/app.h>
#include <xmlsec/openssl/crypto.h>

PyObject *xmlsec_OpenSSLAppInit(PyObject *self, PyObject *args);
PyObject *xmlsec_OpenSSLInit(PyObject *self, PyObject *args);
