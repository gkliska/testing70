PyObject *xmlsec_Init(PyObject *self, PyObject *args);
PyObject *xmlsec_Shutdown(PyObject *self, PyObject *args);
PyObject *xmlsec_CheckVersionExact(PyObject *self, PyObject *args);
PyObject *xmlsec_CheckVersion(PyObject *self, PyObject *args);
PyObject *xmlsec_CheckVersionExt(PyObject *self, PyObject *args);
